﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace QuickPublish.model
{
    public class MusicInfo : PropertyChangedBase
    {
        public String Name { get; set; }
        public String Path { get; set; }
        public String Duration { get; set; }
        public bool IsNew { get; set; }

        private string status;
        public string Status
        {
            get
            {
                return this.status;
            }
            set
            {
                this.status = value;
                RaisePropertyChanged("Status");
            }
        }

        private bool _IsChecked;
        public MusicInfo()
        {
            this.IsNew = false;
        }
        public MusicInfo(string p)
        {
            this.Path = p;
            this.IsNew = false;
        }
        /// <summary>
        /// 是否选中
        /// </summary>
        public bool IsChecked
        {
            get { return _IsChecked; }
            set { _IsChecked = value; RaisePropertyChanged("IsChecked"); }
        }     



        public override string ToString()
        {
            return this.Path;
        }
    }
}
