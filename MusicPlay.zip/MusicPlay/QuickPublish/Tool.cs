﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;
using System.Xml.Linq;
using System.Windows;
using System.Net;
using Shell32;
using System.Runtime.InteropServices;

namespace QuickPublish
{
    public class Tool
    {
        public static string MD5Hash(string fileName)
        {
            if (!File.Exists(fileName)) return string.Empty;
            using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read))
            {
                System.Security.Cryptography.HashAlgorithm md5 = System.Security.Cryptography.MD5.Create();
                return BitConverter.ToString(md5.ComputeHash(fs)).Replace("-", "");
            }
        }


        /// <summary>
        /// 特殊的方法生成的md5串
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        public static string MD5_3(string filename)
        {
            string md = "";
            FileInfo info = new FileInfo(filename);

            if (info.Length < 1024 * 1024)
            {
                md = MD5Hash(filename);
            }
            else
            {
                FileStream file = File.OpenRead(filename);

                StreamReader r = new StreamReader(file);

                byte[] b1 = new byte[2012];
                file.Read(b1, 0, b1.Length);

                byte[] b2 = new byte[1999];
                file.Seek(info.Length / 2 - 1999, SeekOrigin.Begin);
                file.Read(b2, 0, b2.Length);

                byte[] b3 = new byte[2010];
                file.Seek(-2010, SeekOrigin.End);
                file.Read(b3, 0, b3.Length);
                file.Close();

                string tmp = "temp.md5";

                FileStream tmpFile = File.OpenWrite(tmp);
                tmpFile.Write(b1, 0, b1.Length);
                tmpFile.Write(b2, 0, b2.Length);
                tmpFile.Write(b3, 0, b3.Length);
                tmpFile.Close();

                md = MD5Hash(tmp);

                File.Delete(tmp);
            }

            return md.ToLower();
        }

        public static DateTime FROM_UNIXTIME(long timeStamp)
        {
            return DateTime.Parse("1970-01-01 00:00:00").AddSeconds(timeStamp);
        }

        public static long UNIX_TIMESTAMP(DateTime dateTime)
        {
            return (dateTime.Ticks - DateTime.Parse("1970-01-01 00:00:00").Ticks) / 10000000;
        }

        public static UInt32 UnixStamp()
        {
            TimeSpan ts = DateTime.Now - TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
            return Convert.ToUInt32(ts.TotalSeconds);
        }

        #region Console 调试模式

        private const int ATTACH_PARENT_PROCESS = -1;

        public static void AttachParentConsole()
        {
            AttachConsole(ATTACH_PARENT_PROCESS);
        }

        [DllImport("Kernel32.dll", EntryPoint = "AttachConsole", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern void AttachConsole(int dwProcessId);
        #endregion



        /// <summary>
        /// 格式化日期
        /// </summary>
        /// <param name="t"></param>
        /// <returns>例：2000-10-10</returns>
        public static string GetDate(DateTime t)
        {
            return t.ToString("yyyy-MM-dd");
        }

        public static string GetDate()
        {
            return GetDate(DateTime.Now);
        }

        /// <summary>
        /// 格式化本地日期时间
        /// </summary>
        /// <param name="t"></param>
        /// <returns>例：2000-10-10 12:00:00</returns>
        public static string GetDateTime(DateTime t)
        {
            return t.ToString("yyyy-MM-dd HH:mm:ss");
        }

        /// <summary>
        /// 格式化本地日期时间
        /// </summary>
        /// <param name="t"></param>
        /// <returns>例：2000-10-10 12:00:00</returns>
        public static string GetDateTime()
        {
            return DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }

        public static string CreateFile(string dir, string name, string data)
        {
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }

            string filename = dir + "/" + name;

            return CreateFile(filename, data);
        }

        public static string CreateFile(string filename, string data)
        {
            FileStream fs = new FileStream(filename, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            sw.Write(data);
            sw.Close();
            fs.Close();

            return filename;
        }
    }
}