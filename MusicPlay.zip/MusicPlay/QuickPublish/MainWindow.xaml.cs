﻿using QuickPublish.model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Threading;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Tool;
using System.Xml.Linq;
using QuickPublish.viewModel;

namespace QuickPublish
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        #region 表格拖拽
        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += MainWindow_Loaded;

            vm = new PublishViewModel();
            vm.Container = this;
            this.DataContext = vm;


            this.CommandBindings.Add(new CommandBinding(ApplicationCommands.Close, OpenCmdExecuted));
            this.dg.PreviewMouseLeftButtonDown += dgEmployee_PreviewMouseLeftButtonDown;
            this.dg.Drop += dgEmployee_Drop;

            this.PreviewMouseUp += MainWindow_MouseUp;  //需要完全监听鼠标弹起事件，未达到

            this.dg.DragOver += dg_DragOver;
            this.dg.DragLeave += dg_DragLeave;
            this.dg.DragEnter += dg_DragEnter;

        }
        void MainWindow_MouseUp(object sender, MouseButtonEventArgs e)
        {
            LogHelper.Debug("mouseUp");
        }

        void dg_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetFormats()[0] == typeof(MusicInfo).ToString())
            {

            }
            else
            {
                MusicInfo m = new MusicInfo("添加到文件列表");
                m.IsNew = true;
                this.vm.SelectedMusic = m;
            }

        }

        void dg_DragLeave(object sender, DragEventArgs e)
        {
            this.popup1.IsOpen = false;
        }

        /// <summary>
        /// 拖动时，对插入行进行着色处理。1，排序拖动；2，外部文件拖放
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void dg_DragOver(object sender, DragEventArgs e)
        {

            int index = UITools.GetDataGridItemCurrentRowIndex(e.GetPosition, dg);

            for (int i = 0; i < dg.Items.Count; i++)
            {
                DataGridRow r = dg.ItemContainerGenerator.ContainerFromIndex(i) as DataGridRow;
                if (i != index)
                {
                    r.BorderBrush = new SolidColorBrush(Colors.Transparent);
                    r.BorderThickness = new Thickness(0, 0, 0, 0);
                }
                else
                {
                    r.BorderBrush = new SolidColorBrush(Color.FromRgb(32, 164, 230));
                    Thickness th = new Thickness(0, 0, 0, 0);

                    if (index > prevRowIndex) th = new Thickness(0, 0, 0, 1);
                    else if (index < prevRowIndex) th = new Thickness(0, 1, 0, 0);
                    r.BorderThickness = th;
                }
            }

            if (!popup1.IsOpen)
            {
                popup1.IsOpen = true;
            }
            Size popupSize = new Size(popup1.ActualWidth + 110, popup1.ActualHeight + 10);
            Point p = e.GetPosition(this);
            p.X += 10;
            p.Y += 10;
            popup1.PlacementRectangle = new Rect(p, popupSize);

            // if (row != null) dg.SelectedItem = row.Item;
        }

        int prevRowIndex = -1;
        /// <summary>
        /// Defines the Drop Position based upon the index.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void dgEmployee_Drop(object sender, DragEventArgs e)
        {
            this.popup1.IsOpen = false;
            int index = UITools.GetDataGridItemCurrentRowIndex(e.GetPosition, dg);

            if (index < 0 || index == prevRowIndex) return;
            (dg.ItemContainerGenerator.ContainerFromIndex(index) as DataGridRow).BorderThickness = new Thickness(0, 0, 0, 0);


            if (index >= dg.Items.Count - 1)
            {
                index = dg.Items.Count - 1;
            }

            if (vm.SelectedMusic.IsNew) //表示拖动文件至表格
            {
                string[] obj = e.Data.GetData(DataFormats.FileDrop) as string[];
                foreach (string str in obj)
                {
                    this.vm.CheckFile(str, ++index);
                }
            }
            else
            {
                vm.FileList.RemoveAt(prevRowIndex);
                vm.FileList.Insert(index, vm.SelectedMusic);
                prevRowIndex = -1;
            }
        }

        void dgEmployee_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

            prevRowIndex = UITools.GetDataGridItemCurrentRowIndex(e.GetPosition, dg);
            LogHelper.Debug("X " + e.GetPosition(this.dg).X.ToString());
            //如果选中区域在第一列，即点击选择框，则不进行
            if (e.GetPosition(this.dg).X < 30) return;

            if (prevRowIndex < 0) return;
            dg.SelectedIndex = prevRowIndex;

            MusicInfo selectedEmp = dg.Items[prevRowIndex] as MusicInfo;

            if (selectedEmp == null) return;

            DragDropEffects dragdropeffects = DragDropEffects.Move;
            this.vm.SelectedMusic = selectedEmp;
            if (DragDrop.DoDragDrop(dg, selectedEmp, dragdropeffects)
                                != DragDropEffects.None)
            {
                dg.SelectedItem = selectedEmp;
            }
        }

        void OpenCmdExecuted(object target, ExecutedRoutedEventArgs e)
        {
            vm.Stop();
            this.Close();
        }
        #endregion


        PublishViewModel vm;
        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
        }
        protected override void OnClosed(EventArgs e)
        {
            vm.Stop();
            base.OnClosed(e);
        }

        private void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void Min_Window(object sender, RoutedEventArgs e)
        {
            this.WindowState = System.Windows.WindowState.Minimized;
        }

        private void ToolBar_Loaded_1(object sender, RoutedEventArgs e)
        {

            ToolBar toolBar = sender as ToolBar;
            var overflowGrid = toolBar.Template.FindName("OverflowGrid", toolBar) as FrameworkElement;
            if (overflowGrid != null)
            {
                overflowGrid.Visibility = Visibility.Collapsed;
            }

            var mainPanelBorder = toolBar.Template.FindName("MainPanelBorder", toolBar) as FrameworkElement;
            if (mainPanelBorder != null)
            {
                mainPanelBorder.Margin = new Thickness();
            }
        }

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {
            this.vm.CheckAll(((CheckBox) sender).IsChecked.Value);
        }
    }
}