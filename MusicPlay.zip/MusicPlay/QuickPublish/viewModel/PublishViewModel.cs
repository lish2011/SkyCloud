﻿using QuickPublish.model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Tool;
using System.Windows.Input;
using System.Xml.Linq;

namespace QuickPublish.viewModel
{
    public class PublishViewModel : ViewModelBase
    {
        public PublishViewModel()
        {
            this.FileList = new ObservableCollection<MusicInfo>();
            this.begin = "08:00";
            this.end = "09:00";
            this.IsEnable = true;
            this.LoadFile();
        }

        public ObservableCollection<MusicInfo> FileList { get; set; }

        private string begin;
        private string end;
        private MusicInfo selected;

        public MusicInfo SelectedMusic
        {
            get { return this.selected; }
            set
            {
                this.selected = value;
                this.OnPropertyChanged("SelectedMusic");
            }
        }

        public string Begin
        {
            get { return begin; }
            set
            {
                this.begin = value;
                this.OnPropertyChanged("Begin");
            }
        }

        public string End
        {
            get { return end; }
            set
            {
                this.end = value;
                this.OnPropertyChanged("End");
            }
        }

        private bool _isEnable;
        public bool IsEnable
        {
            get { return _isEnable; }
            set
            {
                this._isEnable = value;
                this.OnPropertyChanged("IsEnable");
            }
        }


        private void CheckFile()
        {
            Microsoft.Win32.OpenFileDialog dialog = new Microsoft.Win32.OpenFileDialog();
            dialog.Multiselect = true;
            dialog.Filter = "音频文件(*.mp3)|*.mp3";
            if (dialog.ShowDialog().Value == true)
            {
                for (int i = 0; i < dialog.FileNames.Length; i++)
                {
                    this.CheckFile(dialog.FileNames[i]);
                }

            }
        }

        public void CheckFile(string file)
        {
            this.CheckFile(file, FileList.Count);
        }
        public void CheckFile(string file, int index)
        {
            FileInfo info = new FileInfo(file);
            if (info.Extension.ToLower() != ".mp3") return;

            this.FileList.Insert(index,new MusicInfo() { Path = file });

        }


        public void RemoveFile()
        {
            List<MusicInfo> list = new List<MusicInfo>(this.FileList.ToList<MusicInfo>());
            List<MusicInfo> sl = list.FindAll(f =>
            {
                return f.IsChecked;
            });
            foreach (MusicInfo m in sl)
            {
                this.FileList.Remove(m);
            }

        }
        #region 开始 停止 添加文件、删除文件、全选 命令
        private ICommand _submitCommand, _previewCommand, _selectCommand, _removeCommand, _checkAllCommand;
        public ICommand SubmitCommand
        {
            get
            {
                if (this._submitCommand == null)
                {
                    this._submitCommand = new RelayCommand(
                        execute => this.Start(),
                        canExecute => this.canSubmit());
                }
                return this._submitCommand;
            }
        }

        public ICommand PreviewCommand
        {
            get
            {
                if (this._previewCommand == null)
                {
                    this._previewCommand = new RelayCommand(
                        execute => this.Stop(),
                        canExecute => this.canCancel());
                }
                return this._previewCommand;
            }
        }

        public ICommand SelectCommand
        {
            get
            {
                if (this._selectCommand == null)
                {
                    this._selectCommand = new RelayCommand(
                            execute => this.CheckFile()
                        );
                }
                return this._selectCommand;
            }
        }
        public ICommand RemoveCommand
        {
            get
            {
                if (this._removeCommand == null)
                {
                    _removeCommand = new RelayCommand(
                            execute => this.RemoveFile()
                        );
                }
                return this._removeCommand;
            }
        }

        public ICommand CheckAllCommand
        {
            get
            {
                if (this._checkAllCommand == null)
                {
                    _checkAllCommand = new RelayCommand(
                        execute => this.CheckAll(execute)
                            );
                }
                return _checkAllCommand;
            }
            
        }
        public bool canCancel()
        {
            return true;
        }

        public bool canSubmit()
        {
            return false;
        }



        #endregion


        private void LoadFile()
        {
            string file = AppDomain.CurrentDomain.BaseDirectory + "\\data.xml";


            LogHelper.Info("读取数据:" + file);
            if (System.IO.File.Exists(file))
            {
                XElement xml = XElement.Load(file);
                var files = from book in xml.Elements("file") select book;
                foreach (var f in files)
                {
                    this.FileList.Add(new MusicInfo() { Path = f.Attribute("path").Value });
                }
                this.Begin = xml.Attribute("begin").Value;
                this.End = xml.Attribute("end").Value;
            }
        }
        /// <summary>
        /// 全选或反选列表
        /// </summary>
        /// <param name="param"></param>
        public void CheckAll(object param)
        {
            LogHelper.Debug("CheckAll:"  + param.ToString());
            foreach (MusicInfo m in FileList)
            {
                m.IsChecked = (bool)param;
            }
        }

        /// <summary>
        /// 开始发布
        /// </summary>
        public void Start()
        {
        }

        /// <summary>
        /// 停止
        /// </summary>
        public void Stop()
        {
            
        }
    }
}
