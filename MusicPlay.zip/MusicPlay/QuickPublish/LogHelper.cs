﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace System.Tool
{
    public enum LogType
    {
        File,
        Console
    }
    public class LogHelper
    {
        public static LogType LogType { get; set; }

        public static void Info(string msg)
        {
            Write("[Info] " + msg);
        }

        public static void Info(int msg)
        {
            Info(msg.ToString());
        }

        public static void Debug(string msg)
        {
            Write("[Debug] " + msg);
        }


        public static void Error(string msg)
        {
            Write("[Error] " + msg);
        }

        private static void Write(string msg)
        {
            msg = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ":\t" + msg + "\r\n";
            
            if (LogType == Tool.LogType.Console)
            {
                System.Console.Write(msg);
            }
            else
            {
                System.IO.StreamWriter write = new System.IO.StreamWriter("app.log", true);
                write.Write(msg);
                write.Close();
            }

        }
    }
}
