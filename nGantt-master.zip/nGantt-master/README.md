nGantt
================================
WPF Gantt control

  Really easy to use and has the most common gantt chart features
  View the GanttDemo for usage

  Developed with Microsoft Visual Studio 2010
  .Net Framework 4