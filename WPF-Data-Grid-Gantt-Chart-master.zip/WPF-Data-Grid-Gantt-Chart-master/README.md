# WPF-Data-Grid-Gantt-Chart
Creating a Gantt Chart in WPF data grid
