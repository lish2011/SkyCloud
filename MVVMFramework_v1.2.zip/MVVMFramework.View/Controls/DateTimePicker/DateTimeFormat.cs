﻿namespace MVVMFramework.View
{
    public enum DateTimeFormat
    {
        Custom,
        FullDateTime,
        LongDate,
        LongTime,
        MonthDay,
        RFC1123,
        ShortDate,
        ShortTime,
        ShortDateTime,
        SortableDateTime,
        UniversalSortableDateTime,
        YearMonth
    }
}
