﻿namespace MVVMFramework.View
{
    public enum TimeFormat
    {
        Custom,
        ShortTime,
        LongTime
    }
}
