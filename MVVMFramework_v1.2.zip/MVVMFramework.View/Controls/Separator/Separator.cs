﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace MVVMFramework.View
{
    public class Separator : Control
    {
        static Separator()
        {
            Type ownerType = typeof(Separator);
            DefaultStyleKeyProperty.OverrideMetadata(ownerType, new FrameworkPropertyMetadata(ownerType));
        }

        public static DependencyProperty HeaderProperty =
            DependencyProperty.Register("Header", typeof(string), typeof(Separator));

        public string Header
        {
            get { return (string)GetValue(HeaderProperty); }
            set { SetValue(HeaderProperty, value); }
        }
    }
}
