﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using MVVMFramework.ViewModel;

namespace MVVMFramework.View
{
    /// <summary>
    /// Base implementation of Window (Base View)
    /// </summary>
    public abstract class WindowBase : Window //, IView
    {

        private ViewModelBase viewModel;
        /// <summary>
        /// View Model for current View
        /// </summary>
        protected ViewModelBase ViewModel
        {
            get
            {
                return viewModel;
            }
        }

        protected bool HideOnClose;

        protected WindowBase()
            : this(null)
        {

        }

        protected WindowBase(ViewModelBase viewModel)
        {
            DataContextChanged += windowBase_DataContextChanged;

            DataContext = this.viewModel = viewModel;
            Loaded += windowBase_Loaded;
        }

        #region Refresh View Model Data

        public static readonly DependencyProperty RefreshLookupsOnLoadProperty =
            DependencyProperty.Register("RefreshLookupsOnLoad", typeof (bool), typeof (WindowBase), new PropertyMetadata(true));

        public bool RefreshLookupsOnLoad
        {
            get
            {
                return (bool)GetValue(RefreshLookupsOnLoadProperty);
            }
            set
            {
                SetValue(RefreshLookupsOnLoadProperty, value);
            }
        }

        public static readonly DependencyProperty RefreshLookupsWithForceProperty =
            DependencyProperty.Register("RefreshLookupsWithForce", typeof (bool), typeof (WindowBase), new PropertyMetadata(false));

        public bool RefreshLookupsWithForce
        {
            get
            {
                return (bool)GetValue(RefreshLookupsWithForceProperty);
            }
            set
            {
                SetValue(RefreshLookupsWithForceProperty, value);
            }
        }

        public static readonly DependencyProperty RefreshViewModelOnLoadProperty =
            DependencyProperty.Register("RefreshViewModelOnLoad", typeof (bool), typeof (WindowBase), new PropertyMetadata(true));

        public bool RefreshViewModelOnLoad
        {
            get
            {
                return (bool)GetValue(RefreshViewModelOnLoadProperty);
            }
            set
            {
                SetValue(RefreshViewModelOnLoadProperty, value);
            }
        }

        public static readonly DependencyProperty RefreshViewModelWithForceProperty =
            DependencyProperty.Register("RefreshViewModelWithForce", typeof (bool), typeof (WindowBase), new PropertyMetadata(false));

        public bool RefreshViewModelWithForce
        {
            get
            {
                return (bool)GetValue(RefreshViewModelWithForceProperty);
            }
            set
            {
                SetValue(RefreshViewModelWithForceProperty, value);
            }
        }

        #endregion

        /// <summary>
        /// Called when view is loaded
        /// </summary>
        protected virtual void OnViewLoaded()
        {
            if (RefreshLookupsOnLoad)
            {
                // load lookups
                if (ViewModel != null)
                    ViewModel.RefreshLookups(RefreshLookupsWithForce);
            }

            // refresh
            if (RefreshViewModelOnLoad)
            {
                IRefreshable refreshable = ViewModel as IRefreshable;
                if (refreshable != null)
                    refreshable.Refresh(RefreshViewModelWithForce);
            }
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            if (HideOnClose)
            {
                e.Cancel = true;
                Hide();
            }
            else
            {
                if (ViewModel != null)
                    ViewModel.ViewCloseRequest -= viewModel_ViewCloseRequest;

                base.OnClosing(e);
            }
        }

        #region Private Methods


        private void windowBase_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            ViewModelBase oldContext = e.OldValue as ViewModelBase;
            if (oldContext != null)
                oldContext.ViewCloseRequest -= viewModel_ViewCloseRequest;

            ViewModelBase newContext = e.NewValue as ViewModelBase;
            viewModel = newContext;
            if (newContext != null)
                newContext.ViewCloseRequest += viewModel_ViewCloseRequest;
        }

        private void windowBase_Loaded(object sender, RoutedEventArgs e)
        {
            OnViewLoaded();
        }

        private void viewModel_ViewCloseRequest(bool? obj)
        {
            if (System.Windows.Interop.ComponentDispatcher.IsThreadModal)
            {
                if (ViewModel != null)
                    ViewModel.ViewCloseRequest -= viewModel_ViewCloseRequest;
                DialogResult = obj;
            }
            else
            {
                if (HideOnClose)
                {
                    Hide();
                }
                else
                {
                    if (ViewModel != null)
                        ViewModel.ViewCloseRequest -= viewModel_ViewCloseRequest;

                    Close();
                }
            }
        }

        #endregion
    }
}
