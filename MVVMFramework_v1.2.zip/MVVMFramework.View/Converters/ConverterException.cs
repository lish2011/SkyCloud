﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVVMFramework.View
{
    /// <summary>
    ///  It is an exception thrown by converter, to indicate that the requested conversion cannot be performed.
    /// </summary>
    public class ConverterException : Exception
    {
        public ConverterException(string message)
            : base(message)
        {

        }

        public ConverterException(string message, Exception innerException)
            : base(message, innerException)
        {

        }
    }
}
