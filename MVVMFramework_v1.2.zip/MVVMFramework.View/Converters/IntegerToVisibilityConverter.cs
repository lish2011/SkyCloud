﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace MVVMFramework.View
{
    public class IntegerToVisibilityConverter : ToVisibilityConverterBase
    {
        public int IntegerValue
        {
            get;
            set;
        }

        protected override object TryConvert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            int intValue = System.Convert.ToInt32(value, culture);

            Visibility convertedValue = UseHidden ? Visibility.Hidden : Visibility.Collapsed;
            if (IntegerValue == intValue)
                convertedValue = Visibility.Visible;

            return convertedValue;
        }

        protected override object TryConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (!(value is Visibility))
                throw new Exception("Unexpected value type");

            Visibility visibility = (Visibility)value;
            if (visibility == Visibility.Visible)
                return IntegerValue;

            throw new Exception("Undefined conversion");
        }

        protected override bool GetReversedValue(object value, Type targetType, out object reversedValue)
        {
            return base.GetReversedValue(value, targetType, out reversedValue);
        }
    }
}
