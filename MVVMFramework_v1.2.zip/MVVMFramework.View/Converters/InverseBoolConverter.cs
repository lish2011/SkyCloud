﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVVMFramework.View.Converters
{
    public class InverseBoolConverter : ConverterBase
    {
        protected override object TryConvert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (!(value is bool))
                return ReturnFallbackValue(value, targetType);

            // convert
            bool retValue = !(bool)value;

            // reverse
            if (IsReversed)
                retValue = !retValue;

            return retValue;
        }

        protected override object TryConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (!(value is bool))
                return ReturnFallbackValue(value, targetType);

            // convert
            bool retValue = !(bool)value;

            // reverse
            if (IsReversed)
                retValue = !retValue;

            return retValue;
        }

        protected override bool GetReversedValue(object value, Type targetType, out object reversedValue)
        {
            if (value is bool)
            {
                reversedValue = !(bool)value;
                return true;
            }

            reversedValue = null;
            return false;
        }
    }
}
