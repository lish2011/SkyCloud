﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace MVVMFramework.View
{
    public abstract class ToVisibilityConverterBase : ConverterBase
    {
        /// <summary>
        /// Gets or sets a value indicating whether <see cref="Visibility.Hidden"/> should be returned instead of <see cref="Visibility.Collapsed"/>.
        /// </summary>
        public bool UseHidden
        {
            get;
            set;
        }

        protected override bool GetReversedValue(object value, Type targetType, out object reversedValue)
        {
            if (value is Visibility)
            {
                Visibility visibility = (Visibility)value;
                if (visibility == Visibility.Collapsed || visibility == Visibility.Hidden)
                {
                    reversedValue = Visibility.Visible;
                }
                else
                {
                    reversedValue = UseHidden ? Visibility.Hidden : Visibility.Collapsed;
                }
                return true;
            }

            reversedValue = null;
            return false;
        }

        protected abstract override object TryConvert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture);
        protected abstract override object TryConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture);
    }
}
