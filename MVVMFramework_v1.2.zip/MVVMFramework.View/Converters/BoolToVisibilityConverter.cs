﻿using System;
using System.Globalization;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Data;

namespace MVVMFramework.View
{
    public class BoolToVisibilityConverter : ToVisibilityConverterBase
    {
        protected override object TryConvert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool booleanValue = System.Convert.ToBoolean(value, culture);

            Visibility convertedValue = UseHidden ? Visibility.Hidden : Visibility.Collapsed;
            if (booleanValue)
                convertedValue =  Visibility.Visible;

            return convertedValue;
        }

        protected override object TryConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (!(value is Visibility))
                throw new Exception("Unexpected value type");

            Visibility visibility = (Visibility)value;
            bool convertedValue = visibility == Visibility.Visible;
            return convertedValue;
        }

        protected override bool GetReversedValue(object value, Type targetType, out object reversedValue)
        {
            if (value is bool)
            {
                reversedValue = !(bool)value;
                return true;
            }

            return base.GetReversedValue(value, targetType, out reversedValue);
        }
    }
}
