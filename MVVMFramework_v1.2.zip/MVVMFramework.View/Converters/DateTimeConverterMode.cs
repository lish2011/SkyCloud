﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVVMFramework.View
{
    public enum DateTimeConverterMode : byte
    {
        ToLocal = 0,
        ToUTC = 1,
    }
}
