﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using MVVMFramework.ViewModel;

namespace MVVMFramework.WPFDemo
{
    class UserVM : EditEntityViewModelBase<User>
    {
        public UserVM(User entity, Requests request)
            : base(entity, request)
        {

        }

        protected override bool Save(User entity)
        {
            try
            {
                AppModel.Instance.InsertUser(entity);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(GetExceptionMessage(ex, false), "Unable to insert user", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return false;
        }

        protected override bool Validate(User entity, out string validationMessage)
        {
            if (string.IsNullOrEmpty(entity.UserName))
            {
                validationMessage = "User Name must be specified";
                return false;
            }

            validationMessage = null;
            return true;
        }

        protected override string GetTitle()
        {
            if (Request == Requests.View)
                return string.Format("{0}", Entity.UserName);

            if (Request == Requests.Change)
                return "User will be changed";

            if (Request == Requests.Insert)
                return "User will be added";

            return "User";
        }
    }
}
