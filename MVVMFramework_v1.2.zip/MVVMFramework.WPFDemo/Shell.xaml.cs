﻿using MVVMFramework.View;

namespace MVVMFramework.WPFDemo
{
    /// <summary>
    /// Interaction logic for Shell.xaml
    /// </summary>
    partial class Shell : WindowBase
    {
        private readonly ShellVM vm;

        public Shell()
        {
            DataContext = vm = new ShellVM();

            InitializeComponent();
        }
    }
}
