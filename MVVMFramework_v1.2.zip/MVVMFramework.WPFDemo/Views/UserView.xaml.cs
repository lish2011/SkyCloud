﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MVVMFramework.View;

namespace MVVMFramework.WPFDemo
{
    /// <summary>
    /// Interaction logic for UserView.xaml
    /// </summary>
    partial class UserView : WindowBase
    {
        public UserView(UserVM vm)
            : base(vm)
        {
            InitializeComponent();
        }
    }
}
