﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVVMFramework.WPFDemo
{
    class UserRole
    {
        public int UserID
        {
            get;
            set;
        }

        public int RoleID
        {
            get;
            set;
        }
    }
}
