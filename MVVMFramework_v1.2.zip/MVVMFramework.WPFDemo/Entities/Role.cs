﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MVVMFramework.ViewModel;

namespace MVVMFramework.WPFDemo
{
    class Role : NotifyPropertyChangedBase
    {
        private int roleID;
        public int RoleID
        {
            get
            {
                return roleID;
            }
            set
            {
                if (roleID != value)
                {
                    roleID = value;
                    OnPropertyChanged(() => RoleID);
                }
            }
        }

        private string roleName;
        public string RoleName
        {
            get
            {
                return roleName;
            }
            set
            {
                if (roleName != value)
                {
                    roleName = value;
                    OnPropertyChanged(() => RoleName);
                }
            }
        }

        private string roleDescription;
        public string RoleDescription
        {
            get
            {
                return roleDescription;
            }
            set
            {
                if (roleDescription != value)
                {
                    roleDescription = value;
                    OnPropertyChanged(() => RoleDescription);
                }
            }
        }
    }
}
