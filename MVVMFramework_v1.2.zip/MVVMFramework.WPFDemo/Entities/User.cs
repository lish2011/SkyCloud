﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MVVMFramework.ViewModel;

namespace MVVMFramework.WPFDemo
{
    class User : NotifyPropertyChangedBase
    {
        private int userID;
        public int UserID
        {
            get
            {
                return userID;
            }
            set
            {
                if (userID != value)
                {
                    userID = value;
                    OnPropertyChanged(() => UserID);
                }
            }
        }

        private string userName;

        public string UserName
        {
            get
            {
                return userName;
            }
            set
            {
                if (userName != value)
                {
                    userName = value;
                    OnPropertyChanged(() => UserName);
                }
            }
        }

        private DateTime dateOfBirth;
        public DateTime DateOfBirth
        {
            get
            {
                return dateOfBirth;
            }
            set
            {
                if (dateOfBirth != value)
                {
                    dateOfBirth = value;
                    OnPropertyChanged(() => DateOfBirth);
                }
            }
        }
    }
}
