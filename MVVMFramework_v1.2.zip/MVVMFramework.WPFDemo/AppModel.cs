﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVVMFramework.WPFDemo
{
    class AppModel
    {
        private readonly List<User> users;
        private readonly List<Role> roles;
        private readonly List<UserRole> userRoles;

        private AppModel()
        {
            users = new List<User>();
            roles = new List<Role>();
            userRoles = new List<UserRole>();

            createUsers();
            createRoles();
            createUserRoles();
        }

        private void createUsers()
        {
            users.Add(new User
            {
                UserID = 1,
                UserName = "John Lennon"
            });
            users.Add(new User
            {
                UserID = 2,
                UserName = "Paul McCartney"
            });
            users.Add(new User
            {
                UserID = 3,
                UserName = "George Harrison"
            });
            users.Add(new User
            {
                UserID = 4,
                UserName = "Ringo Starr"
            });
        }

        private void createRoles()
        {
            roles.Add(new Role
            {
                RoleID = 1,
                RoleName = "admin",
                RoleDescription = "Manage everything",
            });

            roles.Add(new Role
            {
                RoleID = 2,
                RoleName = "manager",
                RoleDescription = "Manage some system parameter",
            });

            roles.Add(new Role
            {
                RoleID = 3,
                RoleName = "readonly",
                RoleDescription = "Only view",
            });
        }

        private void createUserRoles()
        {
            userRoles.Add(new UserRole
            {
                UserID = 1,
                RoleID = 1
            });

            userRoles.Add(new UserRole
            {
                UserID = 1,
                RoleID = 2
            });

            userRoles.Add(new UserRole
            {
                UserID = 2,
                RoleID = 3
            });

            userRoles.Add(new UserRole
            {
                UserID = 3,
                RoleID = 3
            });

            userRoles.Add(new UserRole
            {
                UserID = 4,
                RoleID = 1
            });

            userRoles.Add(new UserRole
            {
                UserID = 4,
                RoleID = 2
            });
        }

        public static readonly AppModel Instance = new AppModel();
        
        public IEnumerable<User> GetUsers()
        {
            return users;
        }

        public bool DeleteUser(int userID)
        {
            // remove user roles
            userRoles.RemoveAll(ur => ur.UserID == userID);

            //remove users
            return users.RemoveAll(u => u.UserID == userID) > 0;
        }

        public IEnumerable<Role> GetRoles(int userID)
        {
            return (from r in roles
                    join ur in userRoles on r.RoleID equals ur.RoleID
                    where ur.UserID == userID
                    select r).ToList();
        }

        public void InsertUser(User user)
        {
            user.UserID = users.Any() ? users.Max(u => u.UserID) + 1 : 1;
            users.Add(user);
        }
    }
}
