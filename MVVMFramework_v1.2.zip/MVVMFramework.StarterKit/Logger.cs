﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using log4net;

namespace MVVMFramework.StarterKit
{
    class Logger
    {
        private readonly ILog log;

        #region Ctors

        static Logger()
        {
        }

        private Logger()
        {
            GlobalContext.Properties["LogDir"] = AppSettings.Instance.LogPath;
            log = LogManager.GetLogger(typeof(Logger));
        }

        private readonly static Logger instance = new Logger();
        /// <summary>
        /// Retrieves the single instance of the <see cref="Logger"/>.
        /// </summary>
        public static Logger Instance
        {
            get
            {
                return instance;
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Logs a message with level ERROR on this logger.
        /// </summary>
        /// <param name="message">The message object to log.</param>
        /// <param name="ex">The exception to log, including its stack trace.</param>
        /// <remarks></remarks>
        public void Error(string message, Exception ex)
        {
            log.Error(message, ex);
        }

        /// <summary>
        /// Logs a message with level ERROR on this logger.
        /// </summary>
        /// <param name="message">The message object to log.</param>
        /// <remarks></remarks>
        public void Error(string message)
        {
            log.Error(message);
        }

        /// <summary>
        /// Logs a message with level ERROR on this logger.
        /// </summary>
        /// <param name="ex">The exception to log, including its stack trace.</param>
        /// <remarks></remarks>
        public void Error(Exception ex)
        {
            log.Error(ex);
        }

        /// <summary>
        /// Logs a message with level INFO on this logger.
        /// </summary>
        /// <param name="message">The message object to log.</param>
        /// <remarks></remarks>
        public void Info(string message)
        {
            log.Info(message);
        }

        /// <summary>
        /// Logs a message with level INFO on this logger.
        /// </summary>
        /// <param name="message">The message object to log..</param>
        /// <param name="ex">The exception to log, including its stack trace.</param>
        /// <remarks></remarks>
        public void Info(string message, Exception ex)
        {
            log.Info(message, ex);
        }

        /// <summary>
        /// Logs a message with level DEBUG on this logger
        /// </summary>
        /// <param name="message">The message object to log.</param>
        /// <remarks></remarks>
        public void Debug(string message)
        {
            log.Debug(message);
        }

        /// <summary>
        /// Logs a message with level DEBUG on this logger
        /// </summary>
        /// <param name="message">The message object to log.</param>
        /// <param name="ex">The exception to log, including its stack trace.</param>
        /// <remarks></remarks>
        public void Debug(string message, Exception ex)
        {
            log.Debug(message, ex);
        }

        /// <summary>
        /// Logs a message with level WARNING on this logger
        /// </summary>
        /// <param name="message">The message object to log.</param>
        /// <remarks></remarks>
        public void Warn(string message)
        {
            log.Warn(message);
        }

        /// <summary>
        /// Logs a message with level WARNING on this logger
        /// </summary>
        /// <param name="message">The message object to log.</param>
        /// <param name="ex">The exception to log, including its stack trace.</param>
        /// <remarks></remarks>
        public void Warn(string message, Exception ex)
        {
            log.Warn(message, ex);
        }

        /// <summary>
        /// Gets the exception message, including inner exceptions.
        /// </summary>
        /// <param name="ex">The exception to get message, including its stack trace.</param>
        /// <returns></returns>
        /// <remarks></remarks>
        public string GetExceptionMessage(Exception ex)
        {
            StringBuilder sb = new StringBuilder();

            Exception currentEx = ex;
            while (currentEx != null)
            {
                sb.AppendLine(currentEx.Message);

                currentEx = currentEx.InnerException;
            }
            return sb.ToString();
        }

        #endregion
    }
}
