﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Markup;

namespace MVVMFramework.StarterKit
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void application_startup(object sender, StartupEventArgs e)
        {
            // tell WPF what the current culture is
            FrameworkElement.LanguageProperty.OverrideMetadata(
              typeof(FrameworkElement),
              new FrameworkPropertyMetadata(
                    XmlLanguage.GetLanguage(CultureInfo.CurrentCulture.IetfLanguageTag)));

            new Starter(e).Run();

            Logger.Instance.Info("\"MVVM Framework Starter Kit\" application has been started!");
        }
    }
}
