﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MVVMFramework.View;

namespace MVVMFramework.StarterKit
{
    /// <summary>
    /// Interaction logic for ShellView.xaml
    /// </summary>
    partial class ShellView : WindowBase , IDialogService
    {
        private readonly ShellVM vm;

        public ShellView(ShellVM vm)
            : base(vm)
        {
            this.vm = vm;

            InitializeComponent();
        }

        #region IDialogService

        public bool? ShowDialog(object dialog)
        {
            if (Dispatcher.Thread != Thread.CurrentThread)
            {
                return (bool?)Dispatcher.Invoke(new Func<object, bool?>(ShowDialog), dialog);
            }

            Window window = dialog as Window;
            if (window != null)
            {
                Style windowStyle = System.Windows.Application.Current.Resources["WindowStyle"] as Style;

                if (windowStyle != null && window.Style == null)
                    window.Style = windowStyle;

                Window activeWindow = Application.Current.Windows.OfType<Window>().FirstOrDefault(x => x.IsActive);
                window.Owner = activeWindow;
                return window.ShowDialog();
            }
            return null;
        }

        public void ShowFloatingWindow(object window)
        {
            ShowFloatingWindow(window, null);
        }

        public void ShowFloatingWindow(object window, Window ownerWindow)
        {
            if (Dispatcher.Thread != Thread.CurrentThread)
            {
                Dispatcher.Invoke(new Action<object>(ShowFloatingWindow), window);
            }
            else
            {
                Window showWindow = window as Window;
                if (showWindow != null)
                {
                    Style windowStyle = Application.Current.Resources["WindowStyle"] as Style;

                    if (windowStyle != null && showWindow.Style == null)
                        showWindow.Style = windowStyle;

                    showWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                    showWindow.Owner = ownerWindow;
                    showWindow.ShowActivated = true;
                    showWindow.ShowInTaskbar = true;
                    showWindow.Show();
                }
            }
        }

        public void ShowFloatingWindowOnTop(object window)
        {
            Window activeWindow = Application.Current.Windows.OfType<Window>().FirstOrDefault(x => x.IsActive);
            ShowFloatingWindow(window, activeWindow);
        }

        public void ShowMessage(string message)
        {
            ShowMessage(message, "Сообщение");
        }

        public void ShowMessage(string message, string title)
        {
            if (Application.Current.Dispatcher != null && Application.Current.Dispatcher.Thread != Thread.CurrentThread)
            {
                Application.Current.Dispatcher.Invoke(new Action<string, string>(ShowMessage), message, title);
            }
            else
            {
                Window activeWindow = Application.Current.Windows.OfType<Window>().FirstOrDefault(x => x.IsActive);
                MessageBox.Show(activeWindow ?? this, message, title, MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        public void ShowError(string message)
        {
            ShowError(message, "Ошибка");
        }

        public void ShowError(string message, string title)
        {
            if (Application.Current.Dispatcher != null && Application.Current.Dispatcher.Thread != Thread.CurrentThread)
            {
                Application.Current.Dispatcher.Invoke(new Action<string, string>(ShowError), message, title);
            }
            else
            {
                Window activeWindow = Application.Current.Windows.OfType<Window>().FirstOrDefault(x => x.IsActive);
                MessageBox.Show(activeWindow ?? this, message, title, MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public void ShowWarning(string message)
        {
            ShowWarning(message, "Предупреждение");
        }

        public void ShowWarning(string message, string title)
        {
            if (Application.Current.Dispatcher != null && Application.Current.Dispatcher.Thread != Thread.CurrentThread)
            {
                Application.Current.Dispatcher.Invoke(new Action<string, string>(ShowWarning), message, title);
            }
            else
            {
                Window activeWindow = Application.Current.Windows.OfType<Window>().FirstOrDefault(x => x.IsActive);
                MessageBox.Show(activeWindow ?? this, message, title, MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        public MessageBoxResult ShowQuestion(string message)
        {
            return ShowQuestion(message, "Вопрос");
        }

        public MessageBoxResult ShowQuestion(string message, bool showCancel)
        {
            return ShowQuestion(message, "Вопрос", showCancel);
        }

        public MessageBoxResult ShowQuestion(string message, string title)
        {
            return ShowQuestion(message, title, false);
        }

        public MessageBoxResult ShowQuestion(string message, string title, bool showCancel)
        {
            if (Dispatcher.Thread != Thread.CurrentThread)
                return (MessageBoxResult)Dispatcher.Invoke(new Func<string, string, MessageBoxResult>(ShowQuestion), message, title);

            Window activeWindow = Application.Current.Windows.OfType<Window>().FirstOrDefault(x => x.IsActive);
            return MessageBox.Show(activeWindow ?? this, message, title, showCancel ? MessageBoxButton.YesNoCancel : MessageBoxButton.YesNo, MessageBoxImage.Question);
        }

        #endregion

    }
}
