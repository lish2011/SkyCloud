﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using MVVMFramework.ViewModel;
using System.Diagnostics;

namespace MVVMFramework.StarterKit
{
    class ShellVM : ViewModelBase
    {
        public ShellVM()
        {

        }

        #region Properties

        public string Title
        {
            get
            {
                return "MVVM Framework Starter Kit";
            }
        }

        #endregion

        #region Commands

        private ICommand openLogsCommand;

        public ICommand OpenLogsCommand
        {
            get
            {
                return openLogsCommand = openLogsCommand ?? new RelayCommand(() => Process.Start(AppSettings.Instance.LogPath));
            }
        }

        #endregion
    }
}
