﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using MVVMFramework;

namespace MVVMFramework.StarterKit
{
    static class ViewManager
    {
        public static bool? ShowDialog(object view)
        {
            if (view == null)
                throw new ArgumentNullException("view");

            var service = ServiceManager.Default.ResolveService<IDialogService>();
            if (service == null)
            {
                Window window = view as Window;
                if (window != null)
                    return window.ShowDialog();
            }
            else
            {
                return service.ShowDialog(view);
            }

            throw new Exception(string.Format("Unable to show object \"{0}\" as Window Dialog", view.GetType().FullName));
        }

        public static void ShowException(string message, Exception ex)
        {
            var service = ServiceManager.Default.ResolveService<IDialogService>();
            if (service == null)
            {
                MessageBox.Show(string.Format("{0}\n\r\n\r{1}", message, Logger.Instance.GetExceptionMessage(ex)),
                                "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                service.ShowError(string.Format("{0}\n\r\n\r{1}", message, Logger.Instance.GetExceptionMessage(ex)));
            }
        }

        public static void ShowWarning(string message, string title)
        {
            var service = ServiceManager.Default.ResolveService<IDialogService>();
            if (service == null)
            {
                MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {
                service.ShowWarning(message, title);
            }
        }

        public static void ShowMessage(string message, string title)
        {
            var service = ServiceManager.Default.ResolveService<IDialogService>();
            if (service == null)
            {
                MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                service.ShowMessage(message, title);
            }
        }

        public static void ShowFloatingWindow(object view)
        {
            if (view == null)
                throw new ArgumentNullException("view");

            Window window = view as Window;
            if (window != null)
                window.Show();
            else
                throw new Exception(string.Format("Unable to show object \"{0}\" as Floating Window", view.GetType().FullName));
        }

        public static MessageBoxResult ShowQuestion(string message, string title)
        {
            var service = ServiceManager.Default.ResolveService<IDialogService>();
            if (service == null)
            {
                return MessageBox.Show(message, title, MessageBoxButton.YesNo, MessageBoxImage.Question);
            }
            return service.ShowQuestion(message, title);
        }
    }
}
