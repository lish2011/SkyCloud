﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVVMFramework.StarterKit
{
    /// <summary>
    /// This interface defines a contract for main client area. Any view model can use this to place it's views into this main content region.
    /// </summary>
    public interface IContentRegion : IRegion
    {
        /// <summary>
        /// Shows the specified content.
        /// </summary>
        /// <param name="content">The content.</param>
        void Show(object content);
    }
}
