﻿namespace MVVMFramework.StarterKit
{
    /// <summary>
    /// This interface defines the contract for region that represents status bar within the Shell. 
    /// Any Module can access it to place informatino to status bar.
    /// </summary>
    public interface IStatusRegion : IRegion
    {
        /// <summary>
        /// Adds the item to start of status bar
        /// </summary>
        /// <param name="item">The item to be added to status bar</param>
        /// <returns>Unique identification of item in status bar</returns>
        int AddItemToStart(object item);

        /// <summary>
        /// Adds the item to end of status bar
        /// </summary>
        /// <param name="item">The item to be added to status bar</param>
        /// <returns>Unique identification of item in status bar</returns>
        int AddItemToEnd(object item);

        /// <summary>
        /// Removes the item with specified Item ID
        /// </summary>
        /// <param name="itemID">Unique identification of item in status ba</param>
        void RemoveItem(int itemID);
        
    }
}
