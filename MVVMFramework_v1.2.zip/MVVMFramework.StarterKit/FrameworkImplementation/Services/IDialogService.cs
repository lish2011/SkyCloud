﻿using System.Windows;
using MVVMFramework;

namespace MVVMFramework.StarterKit
{
    /// <summary>
    /// Represents Windows Dialog Service
    /// </summary>
    public interface IDialogService : IService
    {
        /// <summary>
        /// Shows the specified object as dialog.
        /// </summary>
        /// <param name="dialog">The dialog to be shown.</param>
        bool? ShowDialog(object dialog);

        /// <summary>
        /// Shows the specified object as floating window.
        /// </summary>
        /// <param name="window">The window to be shown.</param>
        void ShowFloatingWindow(object window);

        /// <summary>
        /// Shows the specified object as floating window on top of current window.
        /// </summary>
        /// <param name="window">The window to be shown.</param>
        void ShowFloatingWindowOnTop(object window);

        /// <summary>
        /// Shows the message
        /// </summary>
        /// <param name="message">The message to be shown.</param>
        void ShowMessage(string message);

        /// <summary>
        /// Shows the message
        /// </summary>
        /// <param name="message">The message to be shown.</param>
        /// <param name="title">The title.</param>
        void ShowMessage(string message, string title);

        /// <summary>
        /// Shows the error.
        /// </summary>
        /// <param name="message">The message.</param>
        void ShowError(string message);

        /// <summary>
        /// Shows the error.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="title">The title.</param>
        void ShowError(string message, string title);

        /// <summary>
        /// Shows the warning
        /// </summary>
        /// <param name="message">The message.</param>
        void ShowWarning(string message);

        /// <summary>
        /// Shows the warning
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="title">The title.</param>
        void ShowWarning(string message, string title);

        /// <summary>
        /// Shows the question.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <returns></returns>
        MessageBoxResult ShowQuestion(string message);

        /// <summary>
        /// Shows the question.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="showCancel"></param>
        /// <returns></returns>
        MessageBoxResult ShowQuestion(string message, bool showCancel);

        /// <summary>
        /// Shows the question.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="title">The title.</param>
        /// <returns></returns>
        MessageBoxResult ShowQuestion(string message, string title);

        /// <summary>
        /// Shows the question.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="title">The title.</param>
        /// <param name="showCancel"></param>
        /// <returns></returns>
        MessageBoxResult ShowQuestion(string message, string title, bool showCancel);
    }

}
