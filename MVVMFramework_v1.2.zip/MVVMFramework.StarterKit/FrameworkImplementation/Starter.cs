﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using MVVMFramework;
using MVVMFramework.ViewModel;

namespace MVVMFramework.StarterKit
{
    class Starter : ApplicationStarter
    {
        private readonly StartupEventArgs args;

        public Starter(StartupEventArgs args)
        {
            this.args = args;
        }

        protected override object CreateShell()
        {
            ShellVM mainVM = new ShellVM();
            ShellView mainView = new ShellView(mainVM);
            return mainView;
        }

        protected override void ShowShell()
        {
            ShellView mainView = (ShellView)Shell;

            Application.Current.MainWindow = mainView;
            Application.Current.ShutdownMode = ShutdownMode.OnMainWindowClose;

            ViewManager.ShowFloatingWindow(mainView);
        }

        protected override bool Initialize()
        {
            Global.RoutedCommandException += global_RoutedCommandException;
            return true;
        }

        protected override void ApplicationShutdown()
        {
            Application.Current.Shutdown();
        }

        protected override void RegisterRegions(RegionManager regionManager)
        {
            // regionManager.RegisterRegion((IContentRegion)Shell);

            base.RegisterRegions(regionManager);
        }

        protected override void RegisterServices(ServiceManager serviceManager)
        {
            serviceManager.RegisterService((IDialogService)Shell);

            base.RegisterServices(serviceManager);
        }

        #region Event Handlers

        private void global_RoutedCommandException(object sender, RoutedCommandExceptionEventArgs e)
        {
            Logger.Instance.Error("Unhandled RoutedCommand exception", e.Exception);
            ViewManager.ShowException("The requested operation has been completed with error", e.Exception);
            e.Handled = true;
        }

        #endregion
    }
}
