﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVVMFramework
{
    /// <summary>
    /// This is a base interface for other UI region interfaces
    /// </summary>
    public interface IRegion
    {
    }
}
