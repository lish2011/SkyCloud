﻿namespace MVVMFramework
{
    /// <summary>
    /// Base class that provides a basic start sequence and hooks that specific
    /// methods must be overwritten during implementation
    /// </summary>
    public abstract class ApplicationStarter
    {
        private object shell;
        protected object Shell
        {
            get
            {
                return shell;
            }
        }

        /// <summary>
        /// Abstract method that creates the shell.
        /// </summary>
        protected abstract object CreateShell();
        /// <summary>
        /// Abstract method that shows the shell.
        /// </summary>
        protected abstract void ShowShell();
        /// <summary>
        /// Abstract method that initializes this instance.
        /// </summary>
        /// <returns></returns>
        protected abstract bool Initialize();

        protected abstract void ApplicationShutdown();

        /// <summary>
        /// Run applicaiton start logic
        /// </summary>
        public void Run()
        {
            if (Initialize())
            {
                shell = CreateShell();
                RegisterRegions(RegionManager.Default);
                RegisterServices(ServiceManager.Default);
                ShowShell();
            }
            else
            {
                ApplicationShutdown();
            }
        }

        /// <summary>
        /// Virtual method that registers the regions.
        /// </summary>
        /// <param name="regionManager">Region manager</param>
        protected virtual void RegisterRegions(RegionManager regionManager)
        {

        }

        /// <summary>
        /// Virtual method that registers the services.
        /// </summary>
        /// <param name="serviceManager">Service manager</param>
        protected virtual void RegisterServices(ServiceManager serviceManager)
        {

        }
    }
}
