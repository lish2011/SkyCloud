﻿namespace MVVMFramework.ViewModel
{
    /// <summary>
    /// Specifies the behavior of the view model.
    /// </summary>
    public enum Requests : byte
    {
        /// <summary>
        /// View mode
        /// </summary>
        View = 0,
        /// <summary>
        /// Selection mode
        /// </summary>
        Select = 1,
        /// <summary>
        /// Changing mode
        /// </summary>
        Change = 2,
        /// <summary>
        /// Inserting mode
        /// </summary>
        Insert = 3,
    }
}
