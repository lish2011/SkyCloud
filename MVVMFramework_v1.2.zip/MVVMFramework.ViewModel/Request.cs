﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVVMFramework.ViewModel
{
    public enum Request : byte
    {
        View = 0,
        Select = 1,
        Change = 2,
        Insert = 3,
    }
}
