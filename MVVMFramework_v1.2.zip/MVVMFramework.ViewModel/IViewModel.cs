﻿using System;

namespace MVVMFramework.ViewModel
{
    /// <summary>
    /// The ViewModel is a "Model of the View" meaning it is an abstraction 
    /// of the View that also serves in data binding between the View and the Model layers.
    /// </summary>
    public interface IViewModel : IDisposable
    {

    }
}
