﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVVMFramework.ViewModel
{
    /// <summary>
    /// Defines the method that allows to perform asynchronous refresh of browse (when form is open in asycn mode)
    /// </summary>
    public interface IDataChangedController
    {
        /// <summary>
        /// Indicates that Data has been Changed.
        /// </summary>
        void DataChanged();
    }
}
