﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVVMFramework.ViewModel
{
    /// <summary>
    /// Defines a methods to refresh an view model.
    /// </summary>
    public interface IRefreshable
    {
        /// <summary>
        /// Refreshes view model data.
        /// </summary>
        /// <param name="force"></param>
        void Refresh(bool force);
    }
}
