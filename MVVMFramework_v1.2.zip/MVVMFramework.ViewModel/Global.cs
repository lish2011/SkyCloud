﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVVMFramework.ViewModel
{
    public static class Global
    {
        public static event EventHandler<RoutedCommandExceptionEventArgs> RoutedCommandException;

        #region Internal

        internal static void RaiseRoutedCommandExceptionEvent(object sender, RoutedCommandExceptionEventArgs args)
        {
            var handler = RoutedCommandException;
            if (handler != null)
                handler.Invoke(sender, args);
        }

        #endregion
    }
}
