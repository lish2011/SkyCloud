﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace MVVMFramework.ViewModel
{
    public class RoutedCommandExceptionEventArgs : HandledEventArgs
    {
        public RoutedCommandExceptionEventArgs(Exception ex)
        {
            Exception = ex;
        }

        public Exception Exception
        {
            get;
            private set;
        }
    }
}
