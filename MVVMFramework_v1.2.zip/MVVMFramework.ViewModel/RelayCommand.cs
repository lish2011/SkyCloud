﻿using System;
using System.Windows.Input;

namespace MVVMFramework.ViewModel
{
    /// <summary>
    /// <see cref="RelayCommand"/> allows to inject the command's logic via delegates passed into its constructor.
    ///  This approach allows for terse, concise command implementation in ViewModel classes.
    /// </summary>
    public class RelayCommand : ICommand
    {
        private readonly Func<bool> canExecute;
        private readonly Func<object, bool> canExecuteWithParameter;

        private readonly Action action;
        private readonly Action<object> actionWithParameter;

        #region Ctors

        /// <summary>
        /// Initializes a new instance of the <see cref="RelayCommand"/> class.
        /// </summary>
        /// <param name="action">The method to be called when the command is invoked.</param>
        public RelayCommand(Action action)
            : this(action, null)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RelayCommand"/> class.
        /// </summary>
        /// <param name="action">The method to be called when the command is invoked.</param>
        /// <param name="canExecute">The method that determines whether the command can execute in its current state.</param>
        public RelayCommand(Action action, Func<bool> canExecute)
        {
            this.action = action;
            this.canExecute = canExecute;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RelayCommand"/> class.
        /// </summary>
        /// <param name="action">The method to be called when the command is invoked.</param>
        public RelayCommand(Action<object> action)
        {
            this.actionWithParameter = action;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RelayCommand"/> class.
        /// </summary>
        /// <param name="action">The method to be called when the command is invoked.</param>
        /// <param name="canExecute">The method that determines whether the command can execute in its current state.</param>
        public RelayCommand(Action<object> action, Func<bool> canExecute)
            : this(action)
        {
            this.canExecute = canExecute;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RelayCommand"/> class.
        /// </summary>
        /// <param name="action">The method to be called when the command is invoked.</param>
        /// <param name="canExecute">The method that determines whether the command can execute in its current state.</param>
        public RelayCommand(Action<object> action, Func<object, bool> canExecute)
            : this(action)
        {
            this.canExecuteWithParameter = canExecute;
        }

        #endregion

        /// <summary>
        /// Defines the method that determines whether the command can execute in its current state.
        /// </summary>
        /// <param name="parameter">Data used by the command.  If the command does not require data to be passed, this object can be set to null.</param>
        /// <returns>
        /// true if this command can be executed; otherwise, false.
        /// </returns>
        public bool CanExecute(object parameter)
        {
            if (canExecute != null)
                return canExecute();

            return canExecuteWithParameter == null || canExecuteWithParameter(parameter);
        }

        /// <summary>
        /// Occurs when changes occur that affect whether or not the command should execute.
        /// </summary>
        public event EventHandler CanExecuteChanged;

        /// <summary>
        /// Defines the method to be called when the command is invoked.
        /// </summary>
        /// <param name="parameter">Data used by the command.  If the command does not require data to be passed, this object can be set to null.</param>
        public void Execute(object parameter)
        {
            try
            {
                if (action != null)
                    action();
                else if (actionWithParameter != null)
                    actionWithParameter(parameter);
            }
            catch (Exception ex)
            {
                RoutedCommandExceptionEventArgs args = new RoutedCommandExceptionEventArgs(ex);
                Global.RaiseRoutedCommandExceptionEvent(this, args);
                if (!args.Handled)
                    throw;
            }
        }
    }
}
